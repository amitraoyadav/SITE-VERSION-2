import config from  './config.js';

    var isChatOpen;
    var issueId;
    var subIssueId;
    var userName;
    var userPhone;
    var userCity;
    var userZone;
    var userEmail;
    var userComment;
    var searchTerm;
    var enqOTP = '';
    var isFirsttime = true;
    var isId;
$(document).ready(function () {

    var enter = false;
    $(document).keypress(function (event) {
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if (keycode == '13') {
            $('.sendButton').click();
            enter = true;
        }
    });

    if ((getDeviceWidth() <= 480)) {
        $(".chat-message").css({"width": "100%", "height": "100%"});
        $(".chat-arae").css({"width": "100%", "height": "100%"});
        $(".chat-cross").css("display", "none");
    }


	//if (getDeviceWidth() > 480) {
		
    setTimeout(function () {

        if (getDeviceWidth() <= 480 && isChatOpen) {
            $(".chat-cross").css("display", "none");
        } else {
            $(".chat").css("display", "block");
        }
        $(".chat").css({
            "right": "0px"
        }).animate({
            "right": "15px"
        }, 300, 'linear');
        $(".chat-cross").css({
            "right": "0px"
        }).animate({
            "right": "15px"
        }, 300, 'linear');
    }, 5000);

    setTimeout(function () {
        if ($('.chat-message').css('display') == 'none') {
            if ($('.chat-cross').css('display') == 'none') {
                if ((getDeviceWidth() <= 480)) {
                    $(".notification-count").css({"display": "block", "bottom": "62px"}).text(1);
                } else {
                    $(".notification-count").css({"display": "block", "bottom": "75px"}).text(1);
                }
            }
        }
    }, 5500);

    setTimeout(function () {
        if ($('.chat-message').css('display') == 'none') {
            if ($('.chat-cross').css('display') == 'none') {
                $(".notification-count").text();
                if ((getDeviceWidth() <= 480)) {
                    $(".notification-count").css({"display": "block", "bottom": "62px"}).text(2);
                } else {
                    $(".notification-count").css({"display": "block", "bottom": "75px"}).text(2);
                }
            }
        }
    }, 6000);

    setTimeout(function () {
        $(".chat-text").css("display", "block");
        $(".chat-text").css({"right": "85px"}).animate({'zoom': 1.0}, 1000, 'linear');
    }, 6000);
	
	//}

    $(".chat").click(function () {
		//$("#mobchat").hide();
        openChat();
        if (isFirsttime) {
            isFirsttime = false;
            getQuestion();
        }
    });
    $(".chat-text").click(function () {
        openChat();
        if (isFirsttime) {
            isFirsttime = false;
            getQuestion();
        }
    });

    $(".chat-cross").click(function () {
        var r = confirm("Are you sure to leave the chat?");
        if (r == true) {
            window.location.reload();
        }
// closeChat();
    });
    $(".chat-cross-phone").click(function () {
        var r = confirm("Are you sure to leave the chat?");
        if (r == true) {
            window.location.reload();
        }
// closeChat();
    });
//$(".hook").click(function () { closeChat(); });
});

function closeChat() {
    $('.over').removeClass('overlay');
    $(".chat-cross").css("display", "none");
    $(".chat-message").css("display", "none");
    $(".chat-area").css("display", "none");
    $(".chat").css("display", "block");
    $(".chat-text").css("display", "none");
}

function openChat() {
    $('.popup-graybox').on('show.bs.modal', function (e) {
        return e.preventDefault();
    });
// $("#myTestModal").addClass("popup-none");
    $(".notification-count").css("display", "none");
	//$("#mobchat").hide();
    $(".chat").css("display", "none");
    $(".chat-text").css("display", "none");
    $(".chat-cross").css("display", "block");
    isChatOpen = true;
    if ((getDeviceWidth() <= 480)) {
        $(".chat-message").css({"display": "block", "right": "0px", "bottom": "0px"});
        $(".chat-cross").css("display", "none");
    } else {
        $('.over').addClass('overlay');
        $(".chat-message").css({"display": "block", "right": "85px"});
    }

    setTimeout(function () {
        if ((getDeviceWidth() <= 480)) {
            $(".chat-area").css({"display": "block", "right": "0px", "bottom": "0px"});
        } else {
            $(".chat-area").css({"display": "block", "right": "85px"});
        }
    }, 1000);
	
	var page_url = window.location.href;
    $.ajax({

			  url: config.base_url +"start-chat-query",
			  type: 'POST',
			  data: {
					   page_url: page_url,

					},
			  success: function (data) {
				   }
		  });
}

var currentQuestionPosition = 0;
var hasAnswerGive = true;
var questions = [
    {
        "id": "0",
        "questions": ["Hello", "What kind of legal issue are you facing?"],
        "type": "optional",
        "urlOption": config.base_url + "get-chat-issue",
        "urlData": null
    },
    {
        "id": "1",
        "questions": ["What is your %d related to?"],
        "type": "optional",
        "urlOption": config.base_url + "get-chat-sub-issue",
// "urlData" : 1
    },
    {
        "id": "2",
        "questions": ["I will send the details of the right lawyers to you.", "Can I get your name please?"],
        "type": "input",
    },
    {
        "id": "3",
        "questions": ["And your mobile number, please"],
        "type": "input",
    },
    {
        "id": "4",
        "questions": ["So which city do you need help in?", "Type Your City Name"],
        "type": "optional",
        "urlOption": config.base_url + "get-chat-city",
        "urlData": null
    },
    {
        "id": "5",
        "questions": ["So you are looking for legal advice from %s lawyers, right?"],
        "type": "optional",
        "urlOption": null,
        "urlData": null,
        "options": {
            1: "Yes",
            2: "No, Some other city"
        }
    },
    {
        "id": "6",
        "questions": ["Select area where you need legal help?", "You can skip this question by clicking on <span id='skip_button_icon' style='padding: 0;'><b>Skip</b></span>"],
        "type": "optional",
        "urlOption": config.base_url +"get-chat-zones"
    },
    {
        "id": "7",
        "questions": ["Kindly enter your email id", "You can skip this question by clicking on <span id='skip_button_icon' style='padding: 0;'><b>Skip</b>"],
        "type": "input",
    },
    {
        "id": "8",
        "questions": ["Any specific details you want to share? Please type them below..", "You can skip this question by clicking on <span id='skip_button_icon' style='padding: 0;'><b>Skip</b>"],
        "type": "input",
    },
];

var answers = [];

var answerSelected = [];

function adjustScreen(currentQuestionPosition, number) {
    var duration = 500;
    $(".message-window").css({height: (number - 6) + '%'});
    $(".list-wrapper").animate({height: (100 - number) + '%'}, {duration: duration});
    $(".input-wrapper").animate({bottom: ((100 - number) + '%')}, {duration: duration});
}

async function getQuestion() {
    goBottom();
    hasAnswerGive = false;
    var currentQuestion = questions[currentQuestionPosition];

    var elementClicked;
    $(".chat-cross-img").click(function () {
        elementClicked = true;
    });
    window.onbeforeunload = function (e) {
        if (currentQuestionPosition > 0 && currentQuestionPosition < 9) {
            if (elementClicked != true) {
                e = e || window.event;
                if (e) {
                    e.returnValue = 'Sure?';
                }
                return 'Sure?';
                return false;
            } else {
                alert("element clicked");
            }
        }
        ;
    }

    if (currentQuestionPosition >= 6 && currentQuestionPosition <= 11) {
        $(".input-message").keyup(function () {
            if ($(".input-message").val() != '') {
                $(".skipButton").css("display", "none");
                $(".sendButton").css("display", "block");
            } else {
                $(".sendButton").css("display", "none");
                $(".skipButton").css("display", "block");
            }
        })
        if (($('.input-message').prop('disabled'))) {
            $(".skipButton").attr("disabled", true);
        }
        if (currentQuestionPosition != 10) {
            $(".sendButton").css("display", "none");
            $(".skipButton").css("display", "block");
        }
// }
    }
    if (currentQuestionPosition < questions.length) {

        for (var i = 0; i < currentQuestion.questions.length; i++) {

            var question = currentQuestion.questions[i];
            $('.message-window').append(`<div class='computer-question'><img src='${config.base_url}assets/img/chat_loader.gif' class='loading-img'/></div>`);
            goBottom();
            $('.input-message').prop('disabled', true);
            $(".sendButton").removeClass("back-white");
            $(".sendButton").attr("disabled", true);
            $(".skipButton").attr("disabled", true);
            if (!($('.input-message').prop('disabled'))) {
                $('.sendButton').attr("disabled", false);
                $('.skipButton').attr("disabled", false);
            }
            await new Promise(done => setTimeout(() => done(), 1500));
            goBottom();
            if (currentQuestionPosition == 1) {
                question = question.replace('%d', answerSelected[currentQuestionPosition - 1]);
            }
            if (currentQuestionPosition == 5) {
                question = question.replace('%s', $(".city-id").attr("data-info"));
            }
            if(currentQuestionPosition == 9){
                $(".skipButton").css("display",'none');
            }
            if(currentQuestionPosition == 10){
                $(".skipButton").css("display",'none');
                // $(".sendButton").css("display","block");
            }
            question = question.replace('%s', answers[currentQuestionPosition - 1]);
            goBottom();
            $('.message-window .computer-question:last-child').html(question);
            goBottom();
        }
    } else {
        if (currentQuestionPosition != 11) {
            $('.input-message').prop('disabled', true);
            $(".sendButton").removeClass("back-white");
            $(".sendButton").attr("disabled", true);
            $('.sendButton').css("display", "none");
            $('.skipButton').css("display", "none");
            $('.input-message').prop("placeholder", "");
        }

// goBottom();
        //       $('.message-window').append("<div class='computer-question'>कृपया प्रतीक्षा करें| मैं आपकी कानूनी समस्या के लिए हमारे सबसे अच्छे वकीलो की जानकारी ढूंढ रहा हूँ|</div>");
        //       $('.message-window').append("<div class='computer-question' id='lawyer-detail'></div>");
        // $('.message-window').append("<div class='computer-question' id='lawyer-details'></div>");
        //       $('.message-window').append("<div class='computer-question' id='lawyer-thank' style='display: none;'></div>");
        goBottom();
        return false;
    }
    if (currentQuestion.type === 'input') {
        if (currentQuestionPosition == 3 && getDeviceWidth() < 480) {
            $(".input-message").prop('type', 'tel');
        } else {
            $(".input-message").prop('type', 'text');
        }
        $(".input-message").attr("placeholder", "Type here....");
        $('.input-message').prop('disabled', false).focus();
        $(".sendButton").addClass("back-white");
        $(".input-message").keyup(function () {
            if ($(".input-message").val() != '') {
                $(".sendButton").addClass("send-enabled");
                $(".sendButton").attr("disabled", false);
            } else {
                $(".sendButton").removeClass("send-enabled");
                $(".sendButton").attr("disabled", true);
            }
        })
    } else {
        if (currentQuestionPosition == 4 && getDeviceWidth() < 480) {
            $(".input-message").prop('type', 'text');
        }
        $(".input-message").attr("placeholder", "Choose from the options given below..");
        $('#chat-area input').val('').prop('disabled', true);
        $(".sendButton").removeClass("back-white");
        $(".sendButton").attr("disabled", true);
        $('.list-wrapper').html('');

        if (currentQuestion.urlOption != null) {
            if (currentQuestionPosition == 1) {
                var searchTerm = answers ? answers[currentQuestionPosition - 1] : '';
            } else if (currentQuestionPosition == 4) {

                $(".input-message").keyup(function () {
                    if (currentQuestionPosition == 5) {
                        var searchCity = $(".input-message").val();
                        $.ajax({
                            url: currentQuestion.urlOption,
                            type: 'POST',
                            data: {
                                term: searchCity
                            },
                            success: function (data) {
                                $('.list-wrapper').html('');
                                $.each(JSON.parse(data), function (idx, obj) {
                                    $('.list-wrapper').append('<label class="question-option"><input type="radio" value="' + obj.id + '"> ' + obj.text + '</label>');
                                });
                            }
                        });
                    }
                })
            } else if (currentQuestionPosition == 6) {
                var searchTerm = userCity;
                $(".input-message").keyup(function () {
                    if (currentQuestionPosition == 4) {
                        var searchCity2 = $(".input-message").val();
                        $.ajax({
                            url: config.base_url + "get-chat-city",
                            type: 'POST',
                            data: {
                                term: searchCity2
                            },
                            success: function (data) {
                                $('.list-wrapper').html('');
                                $.each(JSON.parse(data), function (idx, obj) {
                                    $('.list-wrapper').append('<label class="question-option"><input type="radio" value="' + obj.id + '"> ' + obj.text + '</label>');
                                });
                            }
                        });
                    }
                })
            } else {
                var searchTerm = currentQuestion.urlData;

            }
            if (currentQuestionPosition == 4) {
                goBottom();
                adjustScreen(currentQuestionPosition, 60);
                $('.input-message').prop('disabled', false).attr("placeholder", "Type here....").focus();
                $(".sendButton").addClass("back-white");

            }
            if (currentQuestionPosition == 5) {
                adjustScreen(currentQuestionPosition, 85);
            }
            if (currentQuestionPosition == 6) {
                $('.input-message').prop('disabled', true).attr("placeholder", "Type here....").focus();
                goBottom();
                $(".sendButton").addClass("back-white");

            }
            if (currentQuestionPosition == 9) {
                adjustScreen(currentQuestionPosition, 75);
            }
            if (currentQuestionPosition == 7) {
                $('.input-message').prop('disabled', false);
            }
            $.ajax({
                url: currentQuestion.urlOption,
                type: 'POST',
                data: {
                    term: searchTerm
                },
                success: function (data) {
                    $('.list-wrapper').html('');

                    $.each(JSON.parse(data), function (idx, obj) {
                        $('.list-wrapper').append('<label class="question-option"><input type="radio" value="' + obj.id + '"> ' + obj.text + '</label>');
                    });
                }
            });

            if (currentQuestionPosition == 6) {
                adjustScreen(currentQuestionPosition, 70);
            } else if (currentQuestionPosition == 5) {
                adjustScreen(currentQuestionPosition, 85);
            } else if (currentQuestionPosition == 9) {
                adjustScreen(currentQuestionPosition, 75);
            } else {
                adjustScreen(currentQuestionPosition, 60)
            }
            goBottom();
        } else {
            if (currentQuestionPosition == 6) {
                adjustScreen(currentQuestionPosition, 70);
            } else if (currentQuestionPosition == 5) {
                adjustScreen(currentQuestionPosition, 85);
            } else if (currentQuestionPosition == 9) {
                adjustScreen(currentQuestionPosition, 75);
            } else {
                adjustScreen(currentQuestionPosition, 60)
            }
            goBottom();
            $.each(currentQuestion.options, function (id, option) {
                $('.list-wrapper').append('<label class="question-option"><input type="radio" value="' + id + '"> ' + option + '</label>');
            });
        }
    }
    currentQuestionPosition++;
}

// var isRunning = false;
// $(".input-message").keyup(function () {
//     if (currentQuestionPosition == 5) {
//         var searchCity = $(".input-message").val();
//         if (searchCity != '' && !isRunning) {
//             setTimeout(function(){
//                 isRunning = true;
//                 $.ajax({
//                     url: "https://lawrato.com/get-chat-city",
//                     type: 'POST',
//                     data: {
//                         term: searchCity
//                     },
//                     success: function (data) {
//                         goBottom();
//                         adjustScreen(currentQuestionPosition, 60);
//                         $('.list-wrapper').html('');
//                         $.each(JSON.parse(data), function (idx, obj) {
//                             $('.list-wrapper').append('<label class="question-option"><input type="radio" value="' + obj.id + '"> ' + obj.text + '</label>');
//                         });
//                         isRunning = false;
//                     }
//                 })
//             },200);
//         } else {
//             adjustScreen(currentQuestionPosition, 100);
//             goBottom();
//         }
//         return;
//     }
// })
$('#send-button').click(function () {

    var errorMessage = '';
    if (($('.input-message').prop('disabled')) && ($('.input-message').val() == '')) {
        return;
    }
    if ($('.input-message').val() != '') {
        hasAnswerGive = true;
    }


    if (currentQuestionPosition == 8) {
        if ($('.input-message').val() != '') {
            answers.push($('.input-message').val());
            userEmail = $('.input-message').val();
            if (IsEmail($(".input-message").val()) == false) {
                errorMessage = "Please enter valid email id";
            } else {
                updateEnquiry(userEmail, "email");
            }

        } else {
            userEmail = null;
            answers.push(null);
        }
    }
    if (currentQuestionPosition == 9) {
        if ($('.input-message').val() != '') {
            userComment = $('.input-message').val();
            answers.push($('.input-message').val());
            updateEnquiry(userComment, "comment");
        } else {
            userComment = '';
            answers.push(null);
        }
        goBottom();
    }
    if (currentQuestionPosition == 11) {
        if ($('.input-message').val() == '') {
            showError("Enter OTP to verify your mobile number");
        } else {
            enqOTP = $('.input-message').val();
            answers.push(null);
            get_video_link(isId, enqOTP);
        }
        goBottom();
    }

    var answer = $('.input-message').val();
    if ($('.input-message').val() != '') {
        $('.message-window').append("<div class='person-reply'>" + answer + "</div>");
        answers.push(answer);
    }
    if (currentQuestionPosition == 3) {
        var name = $(".input-message").val();
        if ($(".input-message").val() == '') {
            errorMessage = "Please enter valid name";
        } else if ($.trim(name).length == 0) {
            errorMessage = "Please enter valid name";
        }
        userName = $('.input-message').val();
        if (userName.length > 20) {
            userName = userName.substring(0, 20);
        }
		
		var stepNumber = 'name';
		var sitelang = 'en';
		var leadsource = 'chat';
		let request = {"step": stepNumber, "lang": sitelang, "source": leadsource};
		makeAjaxCall(config.base_url + "lead-step", request);
    }
    if (currentQuestionPosition == 4) {
        if ($(".input-message").val() == '') {
            errorMessage = "Please enter valid mobile number";
        } else if (($(".input-message").val().length < 10 || $(".input-message").val().length > 15)) {
            errorMessage = "Please enter valid mobile number";
        } else if (isNaN($(".input-message").val())) {
            errorMessage = "Please enter valid mobile number";
        }
        userPhone = $('.input-message').val();
		
		var stepNumber = 'phone';
		var sitelang = 'en';
		var leadsource = 'chat';
		let request = {"step": stepNumber, "lang": sitelang, "source": leadsource};
		makeAjaxCall(config.base_url + "lead-step", request);
    }

    if (currentQuestionPosition == 8) {
        $(".input-message").keyup(function () {
            if ($(".input-message").val() != '') {
                $("#skip_button_icon").css("display", "none");
                $("#send_button_icon").css("display", "block");
            } else {
                $("#send_button_icon").css("display", "none");
                $("#skip_button_icon").css("display", "block");
            }
        })
        $("#send_button_icon").css("display", "none");
        $("#skip_button_icon").css("display", "block");
        if (IsEmail($(".input-message").val()) == false) {
            errorMessage = "Please enter valid email id";
        }
    }
    if (currentQuestionPosition == 5) {
// adjustScreen(currentQuestionPosition,100);
        checkCity($('.input-message').val());
    } else {
        if (errorMessage != '') {
            $(".input-message").focus();
            showError(errorMessage);
        }
        $(".input-message").val('');

        if (errorMessage == '' && hasAnswerGive) {
            getQuestion();
        }
    }
});

$(document).on('change', '.question-option input', function () {
    adjustScreen(currentQuestionPosition, 100);
    $('.list-wrapper').html('');
    if (currentQuestionPosition == 1) {
        issueId = $(this).val();
		
		var stepNumber = 'issue';
		var sitelang = 'en';
		var leadsource = 'chat';
		let request = {"step": stepNumber, "lang": sitelang, "source": leadsource};
		makeAjaxCall(config.base_url + "lead-step", request);
    }
    if (currentQuestionPosition == 2) {
        subIssueId = $(this).val();
		
		var stepNumber = 'subissue';
		var sitelang = 'en';
		var leadsource = 'chat';
		let request = {"step": stepNumber, "lang": sitelang, "source": leadsource};
		makeAjaxCall(config.base_url + "lead-step", request);
    }
    if (currentQuestionPosition == 5) {
        $('.city-id').attr('data-info', $(this).closest('label').text());
        $('.city-id').val($(this).closest('input').val());
        userCity = $(".city-id").val();
		
        answers.push($(this).val());
        
        $('.message-window').css("height", "85%");
        $('.message-window').append("<div class='person-reply'>" + $(this).closest('label').text() + "</div>");
        goBottom();
        getQuestion();
    } else {
        if (currentQuestionPosition != 5) {
            answers.push($(this).val());
            answerSelected.push($(this).closest('label').text());
            $('.message-window').append("<div class='person-reply'>" + $(this).closest('label').text() + "</div>");
        }

        if (currentQuestionPosition == 6) {
            var conformation = $(this).closest('input').val();
            if (conformation == 1) {
				
				var stepNumber = 'city';
				var sitelang = 'en';
				var leadsource = 'chat';
				let request = {"step": stepNumber, "lang": sitelang, "source": leadsource};
				makeAjaxCall(config.base_url + "lead-step", request);
		
                var pageUrl = window.location.href;
                $.ajax({
                    url: config.base_url + "insert-query-chat",
                    type: 'POST',
                    data: {
                        issue_id: issueId,
                        subissue_id: subIssueId,
                        name: userName,
                        phone: userPhone,
                        city: userCity,
                        url: pageUrl
                    },
                    success: function (data) {
                        var res = JSON.parse(data);
                        var response = res[0].response;
                        if (response == 'success') {
                            var isZone = res[0].iszone;
                            isId = res[0].last_id;
                            if (isZone == 0) {
                                currentQuestionPosition = currentQuestionPosition + 1;
                                getQuestion();
                            } else if (isZone == 1) {
                                goBottom();
                                getQuestion();
                            }
                        } else if (response == 'error') {
                            currentQuestionPosition = 15;
                            setTimeout(async function () {
                                $('.message-window').append(`<div class='computer-question'><img src='${config.base_url}assets/img/chat_loader.gif' class='loading-img'/></div>`);
                                goBottom();
                                await new Promise(done => setTimeout(() => done(), 1500));
                                $('.message-window .computer-question:last-child').html("You will get the details of the lawyers on your email id and mobile number");
                            }, 2000);
                            setTimeout(async function () {
                                $('.message-window').append(`<div class='computer-question'><img src='${config.base_url}assets/img/chat_loader.gif' class='loading-img'/></div>`);
                                goBottom();
                                await new Promise(done => setTimeout(() => done(), 1500));
                                $('.message-window .computer-question:last-child').html("Have a good day");
                            }, 4000);
                        }
                        $(".sendButton").hide();
                        $(".input-message").prop("placeholder", "");
                    }
                });
            } else if (conformation == 2) {
                $(".city-id").val('');
                answers.pop();
                answers.pop();
                adjustScreen(currentQuestionPosition, 100);
                currentQuestionPosition = currentQuestionPosition - 2;
            }
            goBottom();
        }

        if (currentQuestionPosition == 7) {
            $(".zone-id").val($(this).closest('input').val());
            if ($(".zone-id").val() == '') {
                userZone = '';
            } else {
                userZone = $(".zone-id").val();
                updateEnquiry(userZone, "zone");
            }
        }

        if (currentQuestionPosition == 10) {
            var conformationVideo = $(this).closest('input').val();
            enqOTP = '';
            if (conformationVideo == 1) {
                // $("#audiomsg").empty();
                updateVideoStatus(isId,2);
                startAudioCall(isId);
                goBottom();
            }else if (conformationVideo == 2) {
                // $("#audiomsg").empty();
                updateVideoStatus(isId,1);
                sendOtp(isId);
                goBottom();
            } else if (conformationVideo == 3) {
                // $("#audiomsg").empty();
                updateVideoStatus(isId,3);
                get_expert_detail(isId, enqOTP);
                goBottom();
            }
        }
        if (currentQuestionPosition != 6) {
            getQuestion();
        }
    }
});

async function showError(errorMessage) {
// $(".input-message").blur();
    $('.message-window').append(`<div class='computer-question'><img src='${config.base_url}assets/img/chat_loader.gif' class='loading-img'/></div>`);
    goBottom();
    await new Promise(done => setTimeout(() => done(), 1500));
    $('.message-window .computer-questin:last-child').html(errorMessage);
// goBottom();
    return false;
}

async function checkCity(checkcity) {
    $.ajax({
        url: config.base_url + "check-city",
        type: 'POST',
        data: {
            city: checkcity
        },
        success: function (data) {
            var res = JSON.parse(data);
            if (res.length == 1) {
                var cityNew = res[0].id;
                $('.city-id').val(cityNew);
                $('.city-id').attr("data-info", checkcity);
                userCity = $('.city-id').val();
                if (userCity != '') {
                    getQuestion();
                }
            } else if (res.length == 0) {
// setTimeout(function(){
                errorMessage = 'Please type correct city name';
                showError(errorMessage);
                if (currentQuestionPosition >= answers.length) {
                    answers.pop();
                }
                adjustScreen(currentQuestionPosition, 60);
                goBottom();
// },1500);

                // $(".input-message").keyup(function(){
                //     if(currentQuestionPosition == 5){
                //         var searchCity = $(".input-message").val();
                //         $.ajax({
                //             url: 'https://lawrato.com/get-chat-city',
                //             type: 'POST',
                //             data: {
                //                 term: searchCity
                //             },
                //             success: function (data) {
                //                 $('.list-wrapper').html('');
                //                 $.each(JSON.parse(data), function (idx, obj) {
                //                     $('.list-wrapper').append('<label class="question-option"><input type="radio" value="' + obj.id + '"> ' + obj.text+ '</label>');
                //                 });
                //             }
                //         });
                //     }
                // })
                $.ajax({
                    url: config.base_url + "get-chat-city",
                    type: 'POST',
                    data: {
                        term: null
                    },
                    success: function (data) {
                        $('.list-wrapper').html('');
                        $.each(JSON.parse(data), function (idx, obj) {
                            $('.list-wrapper').append('<label class="question-option"><input type="radio" value="' + obj.id + '"> ' + obj.text + '</label>');
                        });
                    }
                });
            }
        }
    });
    return false;
}

function sendOtp(id, enqOTP) {
    $.ajax({
        url: config.base_url + "send-otp",
        type: 'POST',
        data: {
            id: id,
        },
        success: function (data) {
            if (data == 'success') {
                // get_expert_detail(id);
                questions.push(
                    {
                        "id": "10",
                        "questions": ["Kindly enter OTP sent to your registered mobile number to initiate video call with the lawyer.<br/><p class ='resend' style='color:blue;cursor: pointer;'><u>Resend OTP?</u></p>"],
                        "type": "input",
                    }
                );
                getQuestion();
            }
            // else if(data == 'error'){
            //     errorMessage = "Error sending OTP. Kindly resed<br/><p class ='resend' style='color:blue;cursor: pointer;'><u>Resend OTP?</u></p>";
            //     showError(errorMessage);
            //     goBottom();
            // }

        }
    });
    return false;
}
function updateVideoStatus(id,status) {
    $.ajax({
        url: config.base_url + "chat/update-video-status",
        type: 'POST',
        data: {
            id: id,
            status:status
        },
        success: function (data) {}
    });
    return false;
}
function sleep(time) {
    var start = Date.now();
    now = start;
    while (now - start < time) {
        now = Date.now();
    }
}

function goBottom() {
    var elem = document.getElementById('message-window');
    elem.scrollTop = elem.scrollHeight;
}

function updateEnquiry(updateTerm, type) {
    var pageUrl = window.location.href;
    $.ajax({
        url: config.base_url + "update-enquiry",
        type: 'POST',
        data: {
            id: isId,
            term: updateTerm,
            type: type
        },
        success: function (data) {
            // if (type == 'comment'){
            //     //var text = "<div style='text-align: center;'><img src='https://lawrato.com/assets/images/lawyer-video-icon.png' style='width: 200px;'/></div><br/>";
            //     //showMessage(text);
            //     questions.push(
            //         {
            //             "id": "9",
            //             "questions": ["<b>Would you like to discuss with the lawyer over a video call right now?</b>"],
            //             "type": "optional",
            //             "urlOption": null,
            //             "urlData": null,
            //             "options": {
            //                 1: "Yes",
            //                 2: "No"
            //             }
            //         }
            //     );
            //     goBottom();
            //     setTimeout(function () {
            //         goBottom();
            //         getQuestion();
            //     }, 1000);
            // }
            if (type == 'comment' && data != '') {
				if(data == 'paynow')
				{
					min = Math.ceil(5);
					max = Math.floor(10);
					var randnum = Math.floor(Math.random() * (max - min)) + min;
					setTimeout(function () {
                    var text = `<center><img src='${config.base_url}assets/img/special-offer-nobg.png' width='100px;' /></center><br/><b><center>You have been offered a 15 minutes phone consultation in just Rs. 399/- only.</center></b><br/><br/><b style='font-size: 16px;'><center>Would you like to avail this offer?</center></b><br/><a style=\"float:left; font-size: 14px; padding: 2px 5px;\" href=\"${config.base_url}check-pay-status/"+isId+"/2\" class=\"button button-default\" id=\"nopayment\">No</a><a style=\"float:right; font-size: 14px; padding: 5px 15px;\" href=\"${config.base_url}check-pay-status/"+isId+"/1\" class=\"button button-primary\" id=\"yespayment\">YES</a><br/><br/>`;
                    showMessage(text);
                    setTimeout(function () {
                        var text = "<b>Select YES</b> or No to continue";
                        showMessage(text);
					}, 1000);
					}, 1000);
					$('.input-message').prop('disabled', true);
					$(".sendButton").removeClass("back-white");
					$(".sendButton").attr("disabled", true);
					$('.sendButton').css("display", "none");
					$('.skipButton').css("display", "none");
					$('.input-message').prop("placeholder", "");
					goBottom();
				}
				else
				{
					var res = JSON.parse(data);
					if (res.videoStatus) {
						updateVideoStatus(isId, 0);
						$(".skipButton").css('display','none');
						// ProgressCountdown(10);
						questions.push(
							{
								"id": "9",
								"questions": ["How would you like to connect with the lawyer?"],
								"type": "optional",
								"urlOption": null,
								"urlData": null,
								"options": {
									1: "Audio Call",
									//2: "Video Call",
									3: "View Details"
								}
							}
						);
						getQuestion();
						goBottom();
					} else {
						setTimeout(function () {
							var text = "You can contact <b>" +res['leadDistribute'][0].disply_name + "</b> on <a href='tel:" + res['leadDistribute'][0].mobile_number + "'><b>" + res['leadDistribute'][0].mobile_number + "</b></a> for your legal issue";
							showMessage(text);
							setTimeout(function () {
								var text = "Lawyer details have been sent to your email id and mobile number";
								showMessage(text);
								setTimeout(function () {
									var text = "Have a good day";
									showMessage(text);
									setTimeout(function () {
										closeChat();
									}, 15000);
								}, 2000);
							}, 2000);
						}, 2000);
					}
				}
            } else if (type == 'comment' && data == '') {
                setTimeout(function () {
                    var text = "Thank you for sharing your legal issue with us";
                    showMessage(text);
                    setTimeout(function () {
                        var text = "We will contact you shortly to share the lawyer details with you";
                        showMessage(text);
                        setTimeout(function () {
                            var text = "Have a good day";
                            showMessage(text);
                            setTimeout(function () {
                                closeChat();
                            }, 15000);
                        }, 2000);
                    }, 2000);
                }, 2000);
                $('.input-message').prop('disabled', true);
                $(".sendButton").removeClass("back-white");
                $(".sendButton").attr("disabled", true);
                $('.sendButton').css("display", "none");
                $('.skipButton').css("display", "none");
                $('.input-message').prop("placeholder", "");
            }
        }
    });
    return true;
}

// if (!($('.input-message').prop('disabled'))) {
$("#skip_button_icon").click(function () {
    $('#skip_button_icon').hide();
    setTimeout(function () {
        $('#skip_button_icon').show();
    }, 2000);
    if (currentQuestionPosition == 7) {
        userZone = null;
    } else if (currentQuestionPosition == 8) {
        userEmail = null;
    } else if (currentQuestionPosition == 9) {
        userComment = null;
        updateEnquiry(userComment, "comment");
    } else if (currentQuestionPosition == 10) {
        if ($('.input-message').val() == '') {
            showError("Enter OTP to verify your mobile number");
        } else {
            var otp = $('.input-message').val();
            get_expert_detail(isId, otp);
// get_expert_detail(isId);
        }
    }
// else if (currentQuestionPosition == 10) {
    //     if ($('.input-message').val() == '') {
    //         showError("Enter OTP to verify your mobile number");
    //     } else {
    //         var enqOTP = $('.input-message').val();
    //         answers.push(null);
    //         // get_expert_detail(isId, enqOTP);
    //         // get_expert_detail(isId);
    //     }
    // }
    currentQuestionPosition = currentQuestionPosition++;
    answers.push(null);
    $(".list-wrapper").html('');
    adjustScreen(currentQuestionPosition, 99);
    getQuestion();
    goBottom();
})

// }

function IsEmail(email) {
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!regex.test(email)) {
        return false;
    } else {
        return true;
    }
}

$(".input-message").focus(function () {
    if (getDeviceWidth() < 480) {
        goBottom();
    }
});


$(window).on('resize', function () {
    $(".message-window").css("padding-bottom", "30px");
    goBottom();
});

function get_expert_detail(id, enqOTP) {
    $.ajax({
        url: config.base_url + "get-chat-lawyer-detail",
        type: 'POST',
        data: {
            lastId: id,
            otp: enqOTP
        },
        success: function (data) {
            if (data == 'otperror') {
                errorMessage = "Incorrect OTP! Kindly enter correct OTP to continue.<br/><p class ='resend' style='color:blue;cursor: pointer;'><u>Resend OTP?</u></p>";
                showError(errorMessage);
                goBottom();
            } else {
                if (data != '') {
                    var res = JSON.parse(data);
                    setTimeout(function () {
                        var text = "You can contact <b>" + res[0].disply_name + "</b> on <a href='tel:" + res[0].mobile_number + "'><b>" + res[0].mobile_number + "</b></a> for your legal issue";
                        showMessage(text);
                        setTimeout(function () {
                            var text = "Lawyer details have been sent to your email id and mobile number";
                            showMessage(text);
                            setTimeout(function () {
                                var text = "Have a good day";
                                showMessage(text);
                                setTimeout(function () {
                                    closeChat();
                                }, 15000);
                            }, 2000);
                        }, 2000);
                    }, 2000);
                } else {
                    setTimeout(function () {
                        var text = "Thank you for sharing your legal issue with us";
                        showMessage(text);
                        setTimeout(function () {
                            var text = "We will contact you shortly to share the lawyer details with you";
                            showMessage(text);
                            setTimeout(function () {
                                var text = "Have a good day";
                                showMessage(text);
                                setTimeout(function () {
                                    closeChat();
                                }, 15000);
                            }, 2000);
                        }, 2000);
                    }, 2000);
                }
                $('.input-message').prop('disabled', true);
                $(".sendButton").removeClass("back-white");
                $(".sendButton").attr("disabled", true);
                $('.sendButton').css("display", "none");
                $('.skipButton').css("display", "none");
                $('.input-message').prop("placeholder", "");
            }


        }
    });
}

function get_video_link(id, enqOTP) {
    $.ajax({
        url: config.base_url + "get-lawyer-video-link",
        type: 'POST',
        data: {
            lastId: id,
            otp: enqOTP
        },
        success: function (data) {
            if (data == 'otperror') {
                var text = "Incorrect OTP! Kindly enter correct OTP to continue.<br/><p class ='resend' style='color:blue;cursor: pointer;'><u>Resend OTP?</u></p>";
                showMessage(text);
// goBottom();
            } else {
                if (data != '') {
                    var res = JSON.parse(data);
                    setTimeout(function () {
                        var text = "Initiating Video Call...";
                        showMessage(text);
                        setTimeout(function () {
                            $('.input-message').prop('disabled', true);
                            $(".sendButton").removeClass("back-white");
                            $(".sendButton").attr("disabled", true);
                            $('.sendButton').css("display", "none");
                            $('.skipButton').css("display", "none");
                            $('.input-message').prop("placeholder", "");
                            closeChat();
                            window.location.replace(res);
                            // var text = "<a href='" + res + "'><b>" + res + "</b></a>";
                            // showMessage(text);
                        }, 1500);
                    }, 2000);
                } else {
                    setTimeout(function () {
                        var text = "Thank you for sharing your legal issue with us";
                        showMessage(text);
                        setTimeout(function () {
                            var text = "We will contact you shortly to share the lawyer details with you";
                            showMessage(text);
                            setTimeout(function () {
                                var text = "Have a good day";
                                showMessage(text);
                                setTimeout(function () {
                                    closeChat();
                                }, 15000);
                            }, 2000);
                        }, 2000);
                    }, 2000);
                }
// $('.input-message').prop('disabled', true);
                // $(".sendButton").removeClass("back-white");
                // $(".sendButton").attr("disabled", true);
                // $('.sendButton').css("display", "none");
                // $('.skipButton').css("display", "none");
                // $('.input-message').prop("placeholder", "");
            }
        }
    });
}

async function showMessage(Message) {
    $('.message-window').append(`<div class='computer-question'><img src='${config.base_url}assets/img/chat_loader.gif' class='loading-img'/></div>`);
    goBottom();
    await new Promise(done => setTimeout(() => done(), 1000));
    $('.message-window .computer-question:last-child').html(Message);
// goBottom();
    return false;
}

function getDeviceWidth() {
    return $(window).width();
}

$(document).ready(function () {
    $(document).on('click', '.resend', function () {
        $.ajax({
            url: config.base_url + "resend-otp",
            type: 'POST',
            data: {
                id: isId
            },
            success: function (data) {
                if (data == 'success') {
                    showMessage("OTP has been sent to your registered mobile number. Kindly check");
                } else {
                    showMessage("Problem in sending OTP. Try Again!!");
                }
            }
        });
    });
})

function startAudioCall(isId) {
    $.ajax({
        url: config.base_url + "get-lawyer-audio-link",
        type: 'POST',
        data: {
            insert_id: isId,
        },
        success: function (data) {
            if(data != ''){
                window.location.replace(data);
            }
        }
    });
}

function ProgressCountdown(timeToStart) {
    let timeleft = timeToStart;
    let downloadTimer = setInterval(function () {
        $("#countdowntimer").empty();
        if (timeleft > 0) {
            $("#countdowntimer").empty();
            $("#countdowntimer").html(timeleft);

        } else {
            clearInterval(downloadTimer);
            let id = isId;
            $.ajax({
                url: config.base_url + "get-lawyer-audio-link",
                type: 'POST',
                data: {
                    insert_id: id,
                },
                // beforeSend: function () {
                //     $("#regForm").css("display", "none");
                //     $("#divSpinner").css({"display": "block", "margin-top": "200px"});
                // },
                // complete: function () {
                //     $("#regForm").css("display", "block");
                //     $("#divSpinner").css({"display": "none"});
                // },
                success: function (data) {
                    if(data != ''){
                        window.location.replace(data);
                    }
                }
            });
        }
        --timeleft;
    }, 1000);
}

function makeAjaxCall(action, requestData) {
    //let ajaxUrl = baseUrl + action;
	let ajaxUrl = action;
    $.ajax({
        url: ajaxUrl,
        type: 'POST',
        data: requestData,
		crossDomain: true,
        success: function (data) {
           
        }
    });
}